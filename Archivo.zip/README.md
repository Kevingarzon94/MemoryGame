# Instrucciones 
Se debe jugar con el teclado, y seguir la secuencia que se va marcando 

# Como se Hizo 
Es un juego creado en javascript haciendo uso de funciones como setTimeout,math.random

